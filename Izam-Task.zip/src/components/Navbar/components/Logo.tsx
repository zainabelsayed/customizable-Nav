/* eslint-disable @next/next/no-img-element */
import React from "react";

const Logo: React.FC = () => {
  return (
    <>
      <img src="/iZAM.svg" alt="iZAM Logo" className="h-5" />
    </>
  );
};

export default Logo;
